# NSBC 73e49d6-dirty (73e49d6)
# Built: 20261106
#
# Quick start:
#   tar xzf nsbc-linux-x86_64-73e49d6-dirty-73e49d6-20261106.tar.gz -C /home/NSBC/
#   cd /home/NSBC
#   ./nsbc-web -c conf/nsbc.yaml &
#   sleep 2
#   ./nsbcd -c conf/nsbc.yaml &
#
# Layout:
#   ./nsbcd           C core daemon
#   ./nsbc_cli        CLI log viewer / SIP trace
#   ./conf/nsbc.yaml  shared config
#   ./mod/            dynamic modules + mod.load
#   ./tls/            auto-gen certs (nsbc-web creates on first run)
#   ./logs/            runtime logs
#   ./run/             UDS sockets
#   ./data/snapshots/  config snapshots
